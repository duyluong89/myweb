<?php
define("SUCCESS","success");
define("ERROR","error");


?>