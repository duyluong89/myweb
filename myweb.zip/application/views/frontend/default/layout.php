<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<?php echo $css?>
		<?php echo $js?>
	</head>
	<body>
		<?php echo $header;?>
		<?php echo $main;?>
		<?php echo $footer;?>
	</body>
</html>