<?php

$lang = array(
	"home"=>"Home",
	"login"=>"Login",
	"logout"=>"Logout"
);
